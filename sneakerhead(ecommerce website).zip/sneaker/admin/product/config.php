<!-- This is for the connection of product data to insert in the database -->
<?php


$con = mysqli_connect('localhost','root','','sneakerhead');


?>